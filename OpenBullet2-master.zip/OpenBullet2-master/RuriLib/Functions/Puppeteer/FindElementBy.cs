﻿namespace RuriLib.Functions.Puppeteer
{
    public enum FindElementBy
    {
        Id,
        Class,
        Selector,
        XPath
    }
}
