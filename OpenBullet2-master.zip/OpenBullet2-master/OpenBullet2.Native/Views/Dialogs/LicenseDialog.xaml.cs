﻿using System.Windows.Controls;

namespace OpenBullet2.Native.Views.Dialogs
{
    /// <summary>
    /// Interaction logic for License.xaml
    /// </summary>
    public partial class LicenseDialog : Page
    {
        public LicenseDialog()
        {
            InitializeComponent();
        }
    }
}
