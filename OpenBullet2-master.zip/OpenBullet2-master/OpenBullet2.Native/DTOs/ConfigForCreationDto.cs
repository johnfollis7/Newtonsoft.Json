﻿namespace OpenBullet2.Native.DTOs
{
    public class ConfigForCreationDto
    {
        public string Name { get; set; }
        public string Author { get; set; }
        public string Category { get; set; }
    }
}
