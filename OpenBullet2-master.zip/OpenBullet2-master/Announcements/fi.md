<p style="font-size: 16px; color: yellowgreen;">TIETOJA</p>

Muistathan pitää OpenBullet2-instanssisi ajan tasalla. Päivitykset korjaavat yleensä virheitä ja parantavat suorituskykyä, joten ne ovat erittäin mukava asia! Päivityksen jälkeen näet luettelon muutoksista napsauttamalla sivun vasemmassa alakulmassa olevaa merkintää, joka näyttää ohjelman nykyisen version, joten tiedät tarkalleen, mitä tässä versiossa on korjattu tai lisätty.
