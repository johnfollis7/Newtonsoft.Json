<p style="font-size: 16px; color: yellowgreen;">INFORMATION</p>

Veuillez garder votre instance OB2 à jour. Les mises à jour permettent de fixer des bugs et améliorent les performances, ce qui est un bon point ! Après avoir mis à jour, vous pourrez consulter la liste des changements en cliquant sur le label, qui montrera la version actuelle du programme (dans le bas-côté gauche), ce qui vous permettra de connaître avec exactitude ce qui à été fixé ou ajouté dans cette version.
