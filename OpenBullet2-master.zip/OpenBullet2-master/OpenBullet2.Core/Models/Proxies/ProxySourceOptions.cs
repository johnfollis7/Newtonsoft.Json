﻿using RuriLib.Models.Proxies;

namespace OpenBullet2.Core.Models.Proxies
{
    /// <summary>
    /// Base class for the options of a <see cref="ProxySource"/>
    /// </summary>
    public abstract class ProxySourceOptions
    {

    }
}
