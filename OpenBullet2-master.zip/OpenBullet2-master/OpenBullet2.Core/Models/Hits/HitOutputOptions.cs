﻿using RuriLib.Models.Hits;

namespace OpenBullet2.Core.Models.Hits
{
    /// <summary>
    /// Base class for options of an <see cref="IHitOutput"/>.
    /// </summary>
    public abstract class HitOutputOptions
    {

    }
}
