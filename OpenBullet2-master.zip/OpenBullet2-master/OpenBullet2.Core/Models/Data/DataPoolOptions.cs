﻿using RuriLib.Models.Data;

namespace OpenBullet2.Core.Models.Data
{
    /// <summary>
    /// Base class for options of a <see cref="DataPool"/>.
    /// </summary>
    public abstract class DataPoolOptions
    {

    }
}
